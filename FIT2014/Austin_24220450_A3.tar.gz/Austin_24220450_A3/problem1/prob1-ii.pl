expr(X):- count(X,0).
count("",0).
count([0'a|T],Y):- Z is Y+1,count(T,Z).
count([0'b|T],Y):- Z is Y-1,count(T,Z).