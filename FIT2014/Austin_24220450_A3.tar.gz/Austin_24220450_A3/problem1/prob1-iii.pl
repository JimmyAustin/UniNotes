expr(L, R) :- num(L, R).
expr(L, R) :- num(L, L1), operator(L1, 0'+, L2), expr(L2, R).
expr(L, R) :- num(L, L1), operator(L1, 0'-, L2), expr(L2, R).
expr(L, R) :- num(L, L1), operator(L1, 0'*, L2), expr(L2, R).
expr(L, R) :- num(L, L1), operator(L1, 0'/, L2), expr(L2, R).
num([D|R], R) :- D >= "0", "9" >= D.
operator([X|L], X, L).