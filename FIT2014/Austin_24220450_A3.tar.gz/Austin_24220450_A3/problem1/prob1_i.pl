expr(L) :- exprA(L).
expr(L) :- exprB(L).

exprA("").
exprA(L) :- append(L1, [0'a,0'b|L2], L), exprA(L1), exprA(L2).
exprB("").
exprB(L) :- append(L1, [0'b,0'a|L2], L), exprB(L1), exprB(L2).