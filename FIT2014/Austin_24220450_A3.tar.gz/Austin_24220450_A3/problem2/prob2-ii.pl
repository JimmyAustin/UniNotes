accept(L) :- initial(Q), accept(Q, L, []).
accept(Q, [H|T], S) :- delta(Q, H, S, Q1, S1), accept(Q1, T, S1).
accept(Q, [], []) :- final(Q).
initial(q0).
final(q1).
delta(q0, 0'a, S, q0, [0'a|S]).
delta(q0, 0'b, [0'a|S], q1, S).
delta(q1, 0'b, [0'a|S], q1, S).