accept(L) :- initial(Q), accept(Q, L, []).
accept(Q, [H|T], S) :- delta(Q, H, S, Q1, S1), accept(Q1, T, S1).
accept(Q, [], []) :- final(Q).
initial(q0).
final(q0).
final(q2).
final(q4).
delta(q0, 0'a, S, q1, [0'a|S]).
delta(q1, 0'b, [0'a|S], q2, S).
delta(q2, 0'a, S, q1, [0'a|S]).

delta(q0, 0'b, S, q3, [0'a|S]).
delta(q3, 0'a, [0'a|S], q4, S).
delta(q4, 0'b, S, q3, [0'a|S]).