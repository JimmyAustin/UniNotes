expr --> "a",expr,"b".
recurse --> "a",recurse,"b".
expr --> "ab".
numA --> [D], {D >= "a", D < "b"}.
numB --> [D], {D >= "b", D < "c"}.

