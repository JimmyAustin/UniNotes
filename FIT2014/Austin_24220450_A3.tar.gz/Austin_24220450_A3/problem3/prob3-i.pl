expr(Z) --> exprA(Z).
expr(Z) --> exprB(Z).
expr(Z) --> "".
exprA(Z) --> numA(X),numB(Y).
exprA(Z) --> numA(X),numB(Y),exprA(D).

exprB(Z) --> numB(X),numA(Y).
exprB(Z) --> numB(X),numA(Y),exprB(D).

numA(X) --> [D], {D >= "a", D < "b", X is D-"a"}.
numB(X) --> [D], {D >= "b", D < "c", X is D-"b"}.