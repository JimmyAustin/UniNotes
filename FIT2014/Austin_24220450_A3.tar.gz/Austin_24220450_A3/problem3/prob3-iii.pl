expr(Z) --> num(Z).
expr(Z) --> num(X), "+", expr(Y), {Z is X+Y}.
expr(Z) --> num(X), "-", expr(Y), {Z is X-Y}.
expr(Z) --> num(X), "*", expr(Y), {Z is X*Y}.
expr(Z) --> num(X), "/", expr(Y), {Z is X/Y}.
num(X) --> [D], {D >= "0", "9" >= D, X is D-"0"}.